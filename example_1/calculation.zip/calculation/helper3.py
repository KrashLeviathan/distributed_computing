#!/usr/bin/env python


def do_something_3(ab, cd, e):
    return cd/ab if e else cd
