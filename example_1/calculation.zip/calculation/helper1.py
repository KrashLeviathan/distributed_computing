#!/usr/bin/env python


def do_something_1(a, b):
    return a + b
